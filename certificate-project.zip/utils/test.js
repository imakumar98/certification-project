var date = new Date();


const todayDate = date.getDate() +'-'+ date.getMonth() +'-'+ date.getFullYear();

console.log(todayDate);